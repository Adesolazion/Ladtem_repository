# LADTEM Attendance — Offline Windows App

A desktop app for marking attendance at LADTEM programs **without internet**. It downloads the full member registry while online, lets you mark attendance offline at the venue, and uploads everything when you reconnect.

---

## How it works (for users)

1. **Setup** — enter the server address and the device token (from the admin panel: *Attendance → Offline Devices*), then **Test connection** and **Save**.
2. **Sync** — while you still have internet, click **Download / Refresh Registry**. This pulls every member, the active sessions, the region list, and (if enabled) this device's reserved LC-code blocks onto the laptop.
3. **Attendance** — at the venue (no internet needed): pick the session, search by name or LC code, tap **Present** (tick *late* if needed). If a session wasn't prepared in advance, tap **＋ New session** to create one offline.
4. **Register** — if enabled for this device, register brand-new members offline. Each person gets a **real LC Code instantly**, drawn from this device's reserved block. Optionally register them for a program at the same time.
5. **Upload** — when back online, click **Upload pending attendance**. New registrations go up first (members, then program registrations), then offline-created sessions, then attendance. Safe to run repeatedly — duplicates are ignored, and possible-duplicate people are flagged for an admin to review rather than silently doubled.

The dot in the top-right shows Online/Offline. The Upload tab shows a badge with how many marks are waiting to be sent.

---

## Building the Windows installer (.exe)

### Option B — Build automatically in the cloud (no Windows PC needed)

This project includes a GitHub Actions workflow that builds the Windows `.exe` for you on GitHub's servers — you never touch a command line.

**One-time setup:**
1. Create a free account at https://github.com and create a new repository (e.g. `ladtem-attendance`).
2. Upload the contents of this folder to the repo. Easiest way: on the repo page, click **Add file -> Upload files**, drag everything in (keep the folder structure, including the `.github` folder), and **Commit**.
   - If GitHub hides the `.github` folder when dragging, upload the other files first, then use **Add file -> Create new file**, type `.github/workflows/build.yml` as the name, and paste in the contents of that file.

**Getting the installer:**
- Every time you upload/commit, GitHub builds the app automatically. Watch progress under the **Actions** tab.
- When it finishes (a few minutes), open the completed run and download **LADTEM-Attendance-Windows** from the **Artifacts** section — inside is your `.exe`.
- Optional: to publish a permanent download, create a **tag** named like `v1.3.0` (Releases -> Draft a new release -> choose a tag). The workflow then attaches the `.exe` to a public Release page.

That's it — share the downloaded `.exe` with any laptop to install it.

---

### Option A — Build on a Windows PC (manual)

You need **Node.js 18+** installed on a Windows PC (https://nodejs.org). Then, in this folder, run **two commands**:

```bash
npm install
npm run dist
```

That's it. `npm install` pulls all dependencies automatically; `npm run dist` produces the installer at:

```
dist/LADTEM Attendance Setup 1.0.0.exe
```

Share that single `.exe` with anyone — it installs the app with a desktop shortcut, all dependencies bundled inside. No internet or extra setup needed on the target machines to *run* it.

### To test without building
```bash
npm install
npm start
```

---

## Notes

- **No native dependencies.** Storage is plain JSON in the user's profile folder and all networking uses Node's built-in modules, so the build never needs compilers or extra tools — `npm install` always just works.
- **Data location:** marked attendance is stored under the Windows user profile (`%APPDATA%/LADTEM Attendance`). It survives restarts and stays until uploaded.
- **Security:** the device token grants read access to the member registry. If a laptop is lost, disable or remove its token in the admin panel and the app can no longer pull or push.
- **Updating the registry:** re-run **Sync** any time you have internet to pick up new members or sessions.

---

## Server requirement

The LADTEM platform must have the **lc-sync** plugin installed (ships in platform v4.6.42+). Its API lives at `https://<your-site>/sync-api`. Issue one device token per laptop in *Admin → Attendance → Offline Devices*.

**For offline registration:** enable **Can register** on the device, then click **+ Codes** to reserve a block of LC codes per region (e.g. 100 each). The device picks these up on its next Sync and hands out real codes offline. Possible-duplicate registrations are queued under *Admin → Attendance → Review Offline Registrations*.
