const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
const { URL } = require('url');

let win;

// ── Local storage (plain JSON in the OS userData dir; no native deps) ──
function dataDir() {
  const dir = app.getPath('userData');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}
function storePath(name) { return path.join(dataDir(), name + '.json'); }
function readStore(name, fallback) {
  try { return JSON.parse(fs.readFileSync(storePath(name), 'utf8')); }
  catch (e) { return fallback; }
}
function writeStore(name, data) {
  fs.writeFileSync(storePath(name), JSON.stringify(data), 'utf8');
  return true;
}

// ── HTTP helper (built-in modules only) ──
function request(method, fullUrl, token, bodyObj) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(fullUrl); } catch (e) { return resolve({ ok: false, error: 'Invalid URL' }); }
    const lib = u.protocol === 'https:' ? https : http;
    const payload = bodyObj ? JSON.stringify(bodyObj) : null;
    const headers = { 'Accept': 'application/json' };
    if (token) headers['X-Sync-Token'] = token;
    if (payload) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(payload); }

    const req = lib.request({
      method,
      hostname: u.hostname,
      port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search,
      headers,
      timeout: 20000,
    }, (res) => {
      let chunks = '';
      res.on('data', (d) => chunks += d);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(chunks); } catch (e) {}
        if (parsed) resolve(parsed);
        else resolve({ ok: false, error: 'Server returned status ' + res.statusCode, raw: chunks.slice(0, 200) });
      });
    });
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'Connection timed out. Check internet / server URL.' }); });
    req.on('error', (e) => resolve({ ok: false, error: 'Network error: ' + e.message }));
    if (payload) req.write(payload);
    req.end();
  });
}

// ── IPC: settings ──
ipcMain.handle('settings:get', () => readStore('settings', { serverUrl: '', token: '' }));
ipcMain.handle('settings:save', (e, s) => writeStore('settings', s));

// ── IPC: connectivity / pull / push ──
ipcMain.handle('api:ping', async (e, { serverUrl, token }) => {
  return await request('GET', joinUrl(serverUrl, '/ping'), token);
});

ipcMain.handle('api:pull', async (e, { serverUrl, token }) => {
  const res = await request('GET', joinUrl(serverUrl, '/pull'), token);
  if (res && res.ok) {
    writeStore('members', res.members || []);
    writeStore('sessions', res.sessions || []);
    writeStore('regions', res.regions || []);
    writeStore('capabilities', { can_register: !!res.can_register, can_create_sessions: !!res.can_create_sessions });
    // Merge code blocks, preserving any local "used" counters we already have.
    const prev = readStore('codeBlocks', []);
    const incoming = (res.code_blocks || []).map((b) => {
      const old = prev.find((p) => p.region_id === b.region_id && b.block_start === p.block_start);
      return { ...b, used: old ? old.used : 0 };
    });
    writeStore('codeBlocks', incoming);
    writeStore('lastSync', { at: new Date().toISOString(), memberCount: (res.members || []).length });
  }
  return res;
});

ipcMain.handle('api:registerMembers', async (e, { serverUrl, token, members }) => {
  return await request('POST', joinUrl(serverUrl, '/register-members'), token, { members });
});
ipcMain.handle('api:registerPrograms', async (e, { serverUrl, token, registrations }) => {
  return await request('POST', joinUrl(serverUrl, '/register-programs'), token, { registrations });
});

ipcMain.handle('api:push', async (e, { serverUrl, token, sessionId, records }) => {
  return await request('POST', joinUrl(serverUrl, '/push'), token, { session_id: sessionId, records });
});

ipcMain.handle('api:createSession', async (e, { serverUrl, token, session }) => {
  return await request('POST', joinUrl(serverUrl, '/session'), token, {
    title: session.title,
    session_type: session.session_type || 'event',
    session_date: session.session_date || null,
    client_uuid: session.client_uuid,
  });
});

// ── IPC: local data ──
ipcMain.handle('local:members', () => readStore('members', []));
ipcMain.handle('local:sessions', () => readStore('sessions', []));
ipcMain.handle('local:lastSync', () => readStore('lastSync', null));
ipcMain.handle('local:regions', () => readStore('regions', []));
ipcMain.handle('local:capabilities', () => readStore('capabilities', { can_register: false, can_create_sessions: false }));
ipcMain.handle('local:codeBlocks', () => readStore('codeBlocks', []));

// Assign the next LC code for a region from this device's reserved block.
ipcMain.handle('local:assignCode', (e, regionId) => {
  const blocks = readStore('codeBlocks', []);
  const b = blocks.find((x) => x.region_id === regionId && (x.block_start + x.used) <= x.block_end);
  if (!b) return { ok: false, error: 'No codes left for this region on this device. Sync to get more, or register online.' };
  const num = b.block_start + b.used;
  b.used += 1;
  writeStore('codeBlocks', blocks);
  const yy = String(b.year).slice(-2);
  const code = `LC${b.region_code}-${yy}-${String(num).padStart(5, '0')}`;
  return { ok: true, lc_code: code };
});

// Pending offline registrations: [{ client_ref, lc_code, surname, first_name, gender, phone, email, region_id, date_of_birth, marital_status, program_id, synced }]
ipcMain.handle('local:pendingRegs:get', () => readStore('pendingRegs', []));
ipcMain.handle('local:pendingRegs:add', (e, reg) => {
  const list = readStore('pendingRegs', []);
  list.push(reg);
  writeStore('pendingRegs', list);
  return { ok: true };
});
ipcMain.handle('local:pendingRegs:markSynced', (e, clientRefs) => {
  const list = readStore('pendingRegs', []);
  list.forEach((r) => { if (clientRefs.includes(r.client_ref)) r.synced = true; });
  writeStore('pendingRegs', list);
  return { ok: true };
});

// Locally-created (offline) sessions: [{ id:"L-<uuid>", title, session_type, session_date, client_uuid, serverId:null }]
ipcMain.handle('local:localSessions:get', () => readStore('localSessions', []));
ipcMain.handle('local:localSessions:add', (e, session) => {
  const list = readStore('localSessions', []);
  list.push(session);
  writeStore('localSessions', list);
  return { ok: true, session };
});
ipcMain.handle('local:localSessions:setServerId', (e, { localId, serverId }) => {
  const list = readStore('localSessions', []);
  const s = list.find((x) => x.id === localId);
  if (s) { s.serverId = serverId; writeStore('localSessions', list); }
  return { ok: true };
});

// Attendance is kept per session id: { [sessionId]: { [lcCode]: {lc_code, checked_in_at, is_late, synced} } }
ipcMain.handle('local:attendance:get', (e, sessionId) => {
  const all = readStore('attendance', {});
  return all[sessionId] || {};
});
ipcMain.handle('local:attendance:mark', (e, { sessionId, record }) => {
  const all = readStore('attendance', {});
  if (!all[sessionId]) all[sessionId] = {};
  if (all[sessionId][record.lc_code]) return { ok: false, already: true };
  all[sessionId][record.lc_code] = { ...record, synced: false };
  writeStore('attendance', all);
  return { ok: true };
});
ipcMain.handle('local:attendance:unmark', (e, { sessionId, lcCode }) => {
  const all = readStore('attendance', {});
  if (all[sessionId] && all[sessionId][lcCode] && !all[sessionId][lcCode].synced) {
    delete all[sessionId][lcCode];
    writeStore('attendance', all);
    return { ok: true };
  }
  return { ok: false };
});
ipcMain.handle('local:attendance:markSynced', (e, { sessionId, lcCodes }) => {
  const all = readStore('attendance', {});
  if (all[sessionId]) {
    lcCodes.forEach((c) => { if (all[sessionId][c]) all[sessionId][c].synced = true; });
    writeStore('attendance', all);
  }
  return { ok: true };
});

function joinUrl(base, suffix) {
  base = (base || '').trim().replace(/\/+$/, '');
  return base + suffix;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1080,
    height: 760,
    minWidth: 880,
    minHeight: 600,
    backgroundColor: '#0D4A36',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
