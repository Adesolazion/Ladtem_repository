const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // settings
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (s) => ipcRenderer.invoke('settings:save', s),
  // network
  ping: (cfg) => ipcRenderer.invoke('api:ping', cfg),
  pull: (cfg) => ipcRenderer.invoke('api:pull', cfg),
  push: (cfg) => ipcRenderer.invoke('api:push', cfg),
  createSession: (cfg) => ipcRenderer.invoke('api:createSession', cfg),
  registerMembers: (cfg) => ipcRenderer.invoke('api:registerMembers', cfg),
  registerPrograms: (cfg) => ipcRenderer.invoke('api:registerPrograms', cfg),
  // local data
  members: () => ipcRenderer.invoke('local:members'),
  sessions: () => ipcRenderer.invoke('local:sessions'),
  lastSync: () => ipcRenderer.invoke('local:lastSync'),
  regions: () => ipcRenderer.invoke('local:regions'),
  capabilities: () => ipcRenderer.invoke('local:capabilities'),
  codeBlocks: () => ipcRenderer.invoke('local:codeBlocks'),
  assignCode: (regionId) => ipcRenderer.invoke('local:assignCode', regionId),
  pendingRegs: () => ipcRenderer.invoke('local:pendingRegs:get'),
  addPendingReg: (reg) => ipcRenderer.invoke('local:pendingRegs:add', reg),
  markRegsSynced: (refs) => ipcRenderer.invoke('local:pendingRegs:markSynced', refs),
  localSessions: () => ipcRenderer.invoke('local:localSessions:get'),
  addLocalSession: (s) => ipcRenderer.invoke('local:localSessions:add', s),
  setLocalSessionServerId: (localId, serverId) => ipcRenderer.invoke('local:localSessions:setServerId', { localId, serverId }),
  getAttendance: (sessionId) => ipcRenderer.invoke('local:attendance:get', sessionId),
  mark: (sessionId, record) => ipcRenderer.invoke('local:attendance:mark', { sessionId, record }),
  unmark: (sessionId, lcCode) => ipcRenderer.invoke('local:attendance:unmark', { sessionId, lcCode }),
  markSynced: (sessionId, lcCodes) => ipcRenderer.invoke('local:attendance:markSynced', { sessionId, lcCodes }),
});
