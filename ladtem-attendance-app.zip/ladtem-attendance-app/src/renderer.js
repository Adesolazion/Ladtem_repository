// ── State ──
let settings = { serverUrl: '', token: '' };
let members = [];
let sessions = [];
let currentSession = '';
let attendance = {}; // for current session: { lc_code: {record} }
let localSessions = []; // offline-created sessions
let allSessions = []; // synced + local, used by the picker

const $ = (id) => document.getElementById(id);
function showMsg(el, text, kind) { el.className = 'msg show ' + kind; el.textContent = text; }
function hideMsg(el) { el.className = 'msg'; }

// ── Tabs ──
document.querySelectorAll('.tab').forEach((t) => {
  t.addEventListener('click', () => switchScreen(t.dataset.screen));
});
function switchScreen(name) {
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.screen === name));
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  $('screen-' + name).classList.add('active');
  if (name === 'sync') refreshSyncStats();
  if (name === 'attend') loadSessionsIntoSelect();
  if (name === 'register') loadRegisterScreen();
  if (name === 'upload') refreshUploadStats();
}

// ── Register (offline) ──
let regPrograms = [];
async function loadRegisterScreen() {
  const caps = await window.api.capabilities();
  const regions = await window.api.regions();
  const blocks = await window.api.codeBlocks();
  regPrograms = (await window.api.sessions()); // reuse sessions list as program hints (programs come via sessions' program_id); fallback simple

  if (!caps.can_register) {
    showMsg($('regMsg'), 'This device is not enabled for offline registration. Ask an admin to enable it and reserve code blocks, then Sync.', 'info');
  } else { hideMsg($('regMsg')); }

  // region dropdown
  $('rRegion').innerHTML = regions.map((r) => `<option value="${r.id}">${escapeHtml(r.name)} (${escapeHtml(r.code)})</option>`).join('');

  // blocks remaining summary
  if (blocks.length) {
    $('regBlocks').innerHTML = 'Codes left: ' + blocks.map((b) => {
      const left = (b.block_end - (b.block_start + b.used) + 1);
      return `<b>${escapeHtml(b.region_code)}</b> ${left}`;
    }).join(' · ');
  } else {
    $('regBlocks').innerHTML = '<span style="color:#C0392B">No code blocks on this device yet — ask admin to reserve some, then Sync.</span>';
  }

  // program dropdown (distinct program_id+name from synced sessions)
  const progs = {};
  (await window.api.sessions()).forEach((s) => { if (s.program_id) progs[s.program_id] = s.program_name || ('Program ' + s.program_id); });
  $('rProgram').innerHTML = '<option value="">— none —</option>' +
    Object.entries(progs).map(([id, nm]) => `<option value="${id}">${escapeHtml(nm)}</option>`).join('');

  renderRecentRegs();
}

async function renderRecentRegs() {
  const regs = (await window.api.pendingRegs()).slice(-8).reverse();
  if (!regs.length) { $('regRecent').innerHTML = ''; return; }
  $('regRecent').innerHTML = '<h2 style="font-size:1rem;margin:18px 0 8px">Recently registered (this device)</h2>' +
    regs.map((r) => `<div class="person"><div class="info"><div class="name">${escapeHtml(r.surname)} ${escapeHtml(r.first_name)}</div><div class="meta">${escapeHtml(r.lc_code)}${r.synced ? '' : ' · not yet uploaded'}</div></div></div>`).join('');
}

$('regSaveBtn').addEventListener('click', async () => {
  const surname = $('rSurname').value.trim();
  const first = $('rFirst').value.trim();
  const regionId = Number($('rRegion').value);
  if (!surname || !first) { showMsg($('regMsg'), 'Enter surname and first name.', 'err'); return; }
  if (!regionId) { showMsg($('regMsg'), 'Pick a region.', 'err'); return; }

  const assigned = await window.api.assignCode(regionId);
  if (!assigned.ok) { showMsg($('regMsg'), assigned.error, 'err'); return; }

  const reg = {
    client_ref: 'reg-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
    lc_code: assigned.lc_code,
    surname, first_name: first,
    gender: $('rGender').value || '',
    phone: $('rPhone').value.trim(),
    email: $('rEmail').value.trim(),
    region_id: regionId,
    date_of_birth: $('rDob').value.trim() || null,
    program_id: $('rProgram').value ? Number($('rProgram').value) : null,
    synced: false,
  };
  await window.api.addPendingReg(reg);
  showMsg($('regMsg'), `✓ Registered ${first} ${surname} — LC Code ${assigned.lc_code}. Give them this code.`, 'ok');
  ['rSurname', 'rFirst', 'rPhone', 'rDob', 'rEmail'].forEach((id) => $(id).value = '');
  $('rSurname').focus();
  await loadRegisterScreen();
  refreshUploadBadge();
});

// ── Connectivity indicator ──
async function checkNet() {
  const online = navigator.onLine;
  $('netDot').className = 'dot ' + (online ? 'online' : 'offline');
  $('netText').textContent = online ? 'Online' : 'Offline';
}
window.addEventListener('online', checkNet);
window.addEventListener('offline', checkNet);

// ── Setup ──
$('testBtn').addEventListener('click', async () => {
  const cfg = { serverUrl: $('serverUrl').value, token: $('token').value };
  if (!cfg.serverUrl || !cfg.token) { showMsg($('setupMsg'), 'Enter both server URL and token.', 'err'); return; }
  showMsg($('setupMsg'), 'Testing…', 'info');
  const res = await window.api.ping(cfg);
  if (res && res.ok) showMsg($('setupMsg'), '✓ Connected to ' + (res.device || 'server') + '. You can Save now.', 'ok');
  else showMsg($('setupMsg'), '✗ ' + ((res && res.error) || 'Could not connect.'), 'err');
});
$('saveBtn').addEventListener('click', async () => {
  settings = { serverUrl: $('serverUrl').value.trim(), token: $('token').value.trim() };
  await window.api.saveSettings(settings);
  showMsg($('setupMsg'), '✓ Saved. Go to Sync to download the registry.', 'ok');
});

// ── Sync ──
async function refreshSyncStats() {
  members = await window.api.members();
  sessions = await window.api.sessions();
  const ls = await window.api.lastSync();
  $('statMembers').textContent = members.length;
  $('statSessions').textContent = sessions.length;
  $('statLastSync').textContent = ls ? new Date(ls.at).toLocaleString() : 'Never';
}
$('syncBtn').addEventListener('click', async () => {
  if (!settings.serverUrl || !settings.token) { switchScreen('setup'); showMsg($('setupMsg'), 'Connect this device first.', 'err'); return; }
  showMsg($('syncMsg'), 'Downloading…', 'info');
  $('syncBtn').disabled = true;
  const res = await window.api.pull(settings);
  $('syncBtn').disabled = false;
  if (res && res.ok) {
    showMsg($('syncMsg'), '✓ Downloaded ' + res.member_count + ' members and ' + (res.sessions ? res.sessions.length : 0) + ' session(s).', 'ok');
    await refreshSyncStats();
  } else {
    showMsg($('syncMsg'), '✗ ' + ((res && res.error) || 'Sync failed.'), 'err');
  }
});

// ── Attendance ──
async function loadSessionsIntoSelect() {
  sessions = await window.api.sessions();
  localSessions = await window.api.localSessions();
  members = await window.api.members();
  // server sessions use numeric ids; local sessions use "L-..." ids
  allSessions = [
    ...sessions.map((s) => ({ id: String(s.id), title: s.title, date: s.session_date, local: false })),
    ...localSessions.map((s) => ({ id: s.id, title: s.title + ' (offline)', date: s.session_date, local: true })),
  ];
  const sel = $('sessionSelect');
  const prev = sel.value;
  sel.innerHTML = '<option value="">Select a session…</option>' +
    allSessions.map((s) => `<option value="${escapeAttr(s.id)}">${escapeHtml(s.title)}${s.date ? ' — ' + s.date : ''}</option>`).join('');
  sel.value = prev;
  if (allSessions.length === 0) {
    $('results').innerHTML = '<li class="empty">No sessions yet. Sync while online, or tap “＋ New session” to create one offline.</li>';
  }
}

// ── New session (offline) ──
$('newSessionBtn').addEventListener('click', () => {
  $('newSessionForm').style.display = $('newSessionForm').style.display === 'none' ? 'block' : 'none';
  $('newSessionTitle').focus();
});
$('cancelSessionBtn').addEventListener('click', () => { $('newSessionForm').style.display = 'none'; $('newSessionTitle').value = ''; });
$('createSessionBtn').addEventListener('click', async () => {
  const title = $('newSessionTitle').value.trim();
  if (!title) { $('newSessionTitle').focus(); return; }
  const uuid = 'dev-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  const session = {
    id: 'L-' + uuid,
    title,
    session_type: 'event',
    session_date: nowStamp().slice(0, 10),
    client_uuid: uuid,
    serverId: null,
  };
  await window.api.addLocalSession(session);
  $('newSessionForm').style.display = 'none';
  $('newSessionTitle').value = '';
  await loadSessionsIntoSelect();
  $('sessionSelect').value = session.id;
  $('sessionSelect').dispatchEvent(new Event('change'));
  refreshUploadBadge();
});
$('sessionSelect').addEventListener('change', async (e) => {
  currentSession = e.target.value;
  if (currentSession) { attendance = await window.api.getAttendance(currentSession); }
  $('searchInput').value = '';
  renderResults('');
  updateMarkedCount();
});
$('searchInput').addEventListener('input', (e) => renderResults(e.target.value));

function updateMarkedCount() {
  const n = Object.keys(attendance).length;
  $('markedCount').textContent = currentSession ? (n + ' marked this session') : '';
}

function renderResults(query) {
  if (!currentSession) { $('results').innerHTML = '<li class="empty">Select a session first.</li>'; return; }
  const q = query.trim().toLowerCase();
  let list = members;
  if (q) {
    list = members.filter((m) => {
      const hay = (m.lc_code + ' ' + m.first_name + ' ' + m.surname + ' ' + (m.other_name || '') + ' ' + (m.phone || '')).toLowerCase();
      return hay.includes(q);
    });
  } else {
    // show marked-first when no query, capped
    list = members.slice(0, 0);
  }
  if (!q) { $('results').innerHTML = '<li class="empty">Start typing a name or LC code…</li>'; return; }
  if (list.length === 0) { $('results').innerHTML = '<li class="empty">No match for "' + escapeHtml(query) + '".</li>'; return; }

  $('results').innerHTML = list.slice(0, 60).map((m) => {
    const marked = attendance[m.lc_code];
    const late = marked && marked.is_late;
    return `<li class="person ${marked ? 'marked' : ''}">
      <div class="info">
        <div class="name">${escapeHtml(m.surname)} ${escapeHtml(m.first_name)} ${marked ? (late ? '<span class="pill">LATE</span>' : '<span class="pill" style="background:#BFE3CE;color:#0D4A36">PRESENT</span>') : ''}</div>
        <div class="meta">${escapeHtml(m.lc_code)}${m.phone ? ' · ' + escapeHtml(m.phone) : ''}${m.gender ? ' · ' + escapeHtml(m.gender) : ''}</div>
      </div>
      ${marked
        ? `<button class="mark-btn done" data-unmark="${escapeAttr(m.lc_code)}">✓ Marked${marked.synced ? '' : ' ✕'}</button>`
        : `<label class="late-toggle"><input type="checkbox" data-late="${escapeAttr(m.lc_code)}"> late</label>
           <button class="mark-btn present" data-mark="${escapeAttr(m.lc_code)}">Present</button>`}
    </li>`;
  }).join('');

  // wire buttons
  $('results').querySelectorAll('[data-mark]').forEach((b) => {
    b.addEventListener('click', async () => {
      const lc = b.getAttribute('data-mark');
      const lateBox = $('results').querySelector(`[data-late="${cssEscape(lc)}"]`);
      const isLate = lateBox && lateBox.checked ? 1 : 0;
      const record = { lc_code: lc, checked_in_at: nowStamp(), is_late: isLate, method: 'offline' };
      const res = await window.api.mark(currentSession, record);
      if (res.ok) { attendance[lc] = { ...record, synced: false }; renderResults($('searchInput').value); updateMarkedCount(); refreshUploadBadge(); }
    });
  });
  $('results').querySelectorAll('[data-unmark]').forEach((b) => {
    b.addEventListener('click', async () => {
      const lc = b.getAttribute('data-unmark');
      if (attendance[lc] && attendance[lc].synced) return; // can't unmark synced
      const res = await window.api.unmark(currentSession, lc);
      if (res.ok) { delete attendance[lc]; renderResults($('searchInput').value); updateMarkedCount(); refreshUploadBadge(); }
    });
  });
}

// ── Upload ──
async function allSessionIds() {
  // returns [{ key, local, localRec }] for every session we might have marks under
  const svr = (await window.api.sessions()).map((s) => ({ key: String(s.id), local: false }));
  const loc = (await window.api.localSessions()).map((s) => ({ key: s.id, local: true, localRec: s }));
  return [...svr, ...loc];
}
async function gatherPending() {
  // returns { sessionKey: [records...] } for unsynced across all sessions
  const out = {};
  for (const s of await allSessionIds()) {
    const att = await window.api.getAttendance(s.key);
    const pend = Object.values(att).filter((r) => !r.synced);
    if (pend.length) out[s.key] = pend;
  }
  return out;
}
async function refreshUploadStats() {
  let pending = 0, synced = 0;
  for (const s of await allSessionIds()) {
    const att = await window.api.getAttendance(s.key);
    Object.values(att).forEach((r) => r.synced ? synced++ : pending++);
  }
  $('statPending').textContent = pending;
  $('statSynced').textContent = synced;
}
async function refreshUploadBadge() {
  let pending = 0;
  for (const s of await allSessionIds()) {
    const att = await window.api.getAttendance(s.key);
    Object.values(att).forEach((r) => { if (!r.synced) pending++; });
  }
  (await window.api.pendingRegs()).forEach((r) => { if (!r.synced) pending++; });
  const badge = $('pendingBadge');
  if (pending > 0) { badge.style.display = 'inline-block'; badge.textContent = pending; }
  else badge.style.display = 'none';
}
$('uploadBtn').addEventListener('click', async () => {
  if (!settings.serverUrl || !settings.token) { switchScreen('setup'); return; }
  $('uploadBtn').disabled = true;

  // ── Step 0: upload offline registrations first (members, then programs) ──
  const pendingRegs = (await window.api.pendingRegs()).filter((r) => !r.synced);
  if (pendingRegs.length) {
    showMsg($('uploadMsg'), 'Uploading ' + pendingRegs.length + ' new registration(s)…', 'info');
    const memberPayload = pendingRegs.map((r) => ({
      client_ref: r.client_ref, lc_code: r.lc_code, surname: r.surname, first_name: r.first_name,
      gender: r.gender, phone: r.phone, email: r.email, region_id: r.region_id, date_of_birth: r.date_of_birth,
    }));
    const mres = await window.api.registerMembers({ serverUrl: settings.serverUrl, token: settings.token, members: memberPayload });
    if (!mres || !mres.ok) {
      $('uploadBtn').disabled = false;
      showMsg($('uploadMsg'), '✗ ' + ((mres && mres.error) || 'Registration upload failed') + ' — your data is safe.', 'err');
      return;
    }
    // mark all attempted as synced (created or flagged-for-review are both "handled")
    await window.api.markRegsSynced(pendingRegs.map((r) => r.client_ref));
    // program registrations for those who chose a program
    const progRegs = pendingRegs.filter((r) => r.program_id).map((r) => ({ lc_code: r.lc_code, program_id: r.program_id }));
    if (progRegs.length) {
      await window.api.registerPrograms({ serverUrl: settings.serverUrl, token: settings.token, registrations: progRegs });
    }
    const reviewed = (mres.results || []).filter((x) => x.status === 'review').length;
    if (reviewed) showMsg($('uploadMsg'), `Registrations sent. ${reviewed} flagged for admin review (possible duplicates).`, 'info');
  }

  // ── Step 1+: upload attendance ──
  const pending = await gatherPending();
  const keys = Object.keys(pending);
  if (keys.length === 0 && !pendingRegs.length) { $('uploadBtn').disabled = false; showMsg($('uploadMsg'), 'Nothing to upload.', 'info'); return; }
  let totalAccepted = 0, totalSkipped = 0, totalUnmatched = 0;
  const locals = await window.api.localSessions();

  for (const key of keys) {
    const records = pending[key];
    let serverSessionId = null;

    if (key.startsWith('L-')) {
      // Locally-created session: ensure it exists on the server first.
      const rec = locals.find((x) => x.id === key);
      if (rec && rec.serverId) {
        serverSessionId = rec.serverId;
      } else if (rec) {
        showMsg($('uploadMsg'), 'Creating session "' + rec.title + '" on server…', 'info');
        const cs = await window.api.createSession({ serverUrl: settings.serverUrl, token: settings.token, session: rec });
        if (cs && cs.ok) {
          serverSessionId = cs.session_id;
          await window.api.setLocalSessionServerId(key, serverSessionId);
        } else {
          $('uploadBtn').disabled = false;
          showMsg($('uploadMsg'), '✗ Could not create session "' + rec.title + '": ' + ((cs && cs.error) || 'error') + '. Your marks are safe.', 'err');
          return;
        }
      }
    } else {
      serverSessionId = Number(key);
    }

    showMsg($('uploadMsg'), 'Uploading attendance…', 'info');
    const res = await window.api.push({ serverUrl: settings.serverUrl, token: settings.token, sessionId: Number(serverSessionId), records });
    if (res && res.ok) {
      totalAccepted += res.accepted; totalSkipped += res.skipped; totalUnmatched += (res.unmatched_count || 0);
      await window.api.markSynced(key, records.map((r) => r.lc_code));
    } else {
      $('uploadBtn').disabled = false;
      showMsg($('uploadMsg'), '✗ ' + ((res && res.error) || 'Upload failed') + ' — your data is safe, try again when online.', 'err');
      return;
    }
  }
  $('uploadBtn').disabled = false;
  showMsg($('uploadMsg'), `✓ Uploaded. Accepted ${totalAccepted}, already-there ${totalSkipped}${totalUnmatched ? ', unmatched ' + totalUnmatched : ''}.`, 'ok');
  await refreshUploadStats();
  refreshUploadBadge();
});

// ── Helpers ──
function nowStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
function escapeHtml(s) { return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function escapeAttr(s) { return escapeHtml(s); }
function cssEscape(s) { return String(s).replace(/["\\]/g, '\\$&'); }

// ── Init ──
(async function init() {
  checkNet();
  settings = await window.api.getSettings();
  if (settings.serverUrl) $('serverUrl').value = settings.serverUrl;
  if (settings.token) $('token').value = settings.token;
  members = await window.api.members();
  sessions = await window.api.sessions();
  refreshUploadBadge();
  if (settings.serverUrl && settings.token) {
    if (members.length > 0) switchScreen('attend'); else switchScreen('sync');
  }
})();
